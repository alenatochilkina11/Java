/**
 * A class to launch Huffman Coder
 * @author Alena Tochilkina
 */

public class HuffmanCompressor {

    public static void main(String[] args){

        HuffmanTree.huffmanCoder(args[0], args[1]);

        //Please, use the example of input/output names below to call the main method
//        HuffmanTree.huffmanCoder("TheCapitansDaughter_ASPushkin.txt", "TheCapitansDaughter_ASPushkinEncoded.txt");



    }

}
